package hello

object World extends App {
  println ("Hello, World!")
}